"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, RotateCcw, Coffee, Flame, Brain } from "lucide-react";

type Task = { id: string; text: string; mins: number; deep: boolean; urgent: boolean; rot: number };
type Slot = Task & { start: number };

const PRESETS: Record<string, string> = {
  "Launch week": "Finish Q3 board report, reply to Maya about the launch, urgent: fix checkout bug, book dentist, review Sam's design draft, plan next week",
  "Quiet Friday": "Write newsletter draft, send invoices, call landlord, research standing desks, clear inbox, urgent: submit expense report",
};

const parse = (raw: string): Task[] =>
  raw.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean).slice(0, 7).map((text, i) => {
    const t = text.toLowerCase();
    const deep = /write|report|design|plan|review|draft|build|fix|research/.test(t);
    const quick = /call|email|reply|book|send|pay|invoice|clear|submit/.test(t);
    return {
      id: `${i}-${text}`,
      text: text.replace(/^urgent:\s*/i, ""),
      deep,
      urgent: /urgent|asap|today|due/.test(t),
      mins: deep ? 90 : quick ? 20 : 45,
      rot: ((i * 7) % 9) - 4,
    };
  });

const schedule = (tasks: Task[]): Slot[] => {
  const order = [...tasks].sort((a, b) => Number(b.urgent) - Number(a.urgent) || Number(b.deep) - Number(a.deep));
  let t = 540; // 9:00 AM
  return order.map((task) => {
    if (t < 780 && t + task.mins > 720) t = 780; // keep 12:00-1:00 free
    const slot = { ...task, start: t };
    t += task.mins;
    return slot;
  });
};

const fmt = (m: number) => {
  const h = Math.floor(m / 60);
  return `${((h + 11) % 12) + 1}:${String(m % 60).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
};

export default function Demo() {
  const [raw, setRaw] = useState(PRESETS["Launch week"]);
  const [planned, setPlanned] = useState(false);
  const touched = useRef(false);
  const tasks = useMemo(() => parse(raw), [raw]);
  const slots = useMemo(() => schedule(tasks), [tasks]);
  const list: Task[] = planned ? slots : tasks;

  // The one orchestrated moment: the pile snaps into a day on load.
  useEffect(() => {
    const id = setTimeout(() => { if (!touched.current) setPlanned(true); }, 1600);
    return () => clearTimeout(id);
  }, []);

  const act = (fn: () => void) => { touched.current = true; fn(); };
  const load = (text: string) => act(() => { setRaw(text); setPlanned(false); });

  return (
    <div className="rounded-3xl bg-white p-5 shadow-[0_30px_80px_-30px_rgba(27,19,64,.35)] ring-1 ring-ink/10 sm:p-6">
      <label htmlFor="dump" className="text-sm font-medium">What's on your mind today?</label>
      <textarea
        id="dump" rows={3} value={raw} onChange={(e) => load(e.target.value)}
        className="mt-2 w-full resize-none rounded-xl bg-mist p-3 text-sm leading-relaxed"
      />
      <div className="mt-2 flex flex-wrap items-center gap-2">
        {Object.entries(PRESETS).map(([name, text]) => (
          <button key={name} type="button" onClick={() => load(text)} className="rounded-full border border-ink/15 px-3 py-1 text-xs transition hover:bg-mist">
            {name}
          </button>
        ))}
        <button
          type="button" disabled={!tasks.length} onClick={() => act(() => setPlanned((p) => !p))}
          className="ml-auto inline-flex items-center gap-2 rounded-full bg-iris px-4 py-2 text-sm font-medium text-white transition hover:bg-ink disabled:opacity-40"
        >
          {planned ? <><RotateCcw size={16} /> Shuffle back</> : <><Sparkles size={16} /> Plan my day</>}
        </button>
      </div>

      <motion.ul layout aria-live="polite" className={`mt-5 min-h-[280px] ${planned ? "flex flex-col gap-2" : "flex flex-wrap content-start gap-2"}`}>
        {list.map((task) => (
          <motion.li
            layout key={task.id}
            animate={{ rotate: planned ? 0 : task.rot }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
            className={planned
              ? `flex items-center gap-3 rounded-xl border-l-4 bg-mist px-3 py-2.5 text-sm ${task.urgent ? "border-iris" : task.deep ? "border-sea" : "border-ink/20"}`
              : "rounded-full bg-white px-3.5 py-1.5 text-sm shadow-sm ring-1 ring-ink/15"}
          >
            {planned && <span className="w-[4.5rem] shrink-0 text-xs tabular-nums text-ink/60">{fmt((task as Slot).start)}</span>}
            <span className="flex-1">{task.text}</span>
            {planned && (
              <span className="flex shrink-0 items-center gap-1.5 text-xs text-ink/60">
                {task.urgent && <Flame size={14} className="text-iris" aria-label="Urgent" />}
                {task.deep && <Brain size={14} className="text-sea" aria-label="Deep work" />}
                {task.mins}m
              </span>
            )}
          </motion.li>
        ))}
      </motion.ul>

      <p className="mt-3 flex items-center gap-2 text-xs text-ink/60">
        {planned ? <><Coffee size={14} /> 12:00 to 1:00 PM stays free.</> : "Edit the list, then plan it. This demo runs in your browser."}
      </p>
    </div>
  );
}
