"use client";
import { FormEvent, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown, Inbox, Menu, RefreshCw, ShieldCheck, Waves, X, Zap } from "lucide-react";

const links: [string, string][] = [["Features", "#features"], ["Pricing", "#pricing"], ["FAQ", "#faq"]];

export function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-30 border-b border-ink/10 bg-mist/80 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
        <a href="#" className="flex items-center gap-2 font-display text-xl font-bold"><Waves size={22} className="text-iris" />FlowAI</a>
        <ul className="hidden items-center gap-8 text-sm md:flex">
          {links.map(([l, h]) => <li key={h}><a href={h} className="transition hover:text-iris">{l}</a></li>)}
        </ul>
        <a href="#join" className="hidden rounded-full bg-ink px-4 py-2 text-sm font-medium text-white transition hover:bg-iris md:inline-block">Join the waitlist</a>
        <button className="md:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden md:hidden">
            <ul className="flex flex-col px-5 pb-4">
              {[...links, ["Join the waitlist", "#join"] as [string, string]].map(([l, h]) => (
                <li key={h}><a href={h} onClick={() => setOpen(false)} className="block py-3 text-lg font-medium">{l}</a></li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

const features = [
  { icon: Zap, title: "Plans around your energy", text: "Hard thinking lands in your sharpest hours. Quick replies fill the gaps between." },
  { icon: Inbox, title: "Captures from anywhere", text: "Forward an email, paste a Slack thread, or talk to your phone. It all lands in one list." },
  { icon: ShieldCheck, title: "Protects your focus", text: "Meetings stop eating deep work. FlowAI holds blocks and moves small tasks around them." },
  { icon: RefreshCw, title: "Re-plans when things slip", text: "Ran over? Tap once and the rest of the day reshuffles itself." },
];

export function Features() {
  return (
    <section id="features" className="mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-[1fr_1.4fr]">
      <h2 className="font-display text-4xl font-bold leading-tight tracking-tight lg:sticky lg:top-28 lg:self-start lg:text-5xl">
        Built for how days actually go.
      </h2>
      <ul className="divide-y divide-ink/10 border-y border-ink/10">
        {features.map(({ icon: Icon, title, text }) => (
          <li key={title} className="flex gap-5 py-7">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-iris/10 text-iris"><Icon size={22} /></span>
            <div>
              <h3 className="font-display text-xl font-semibold">{title}</h3>
              <p className="mt-1.5 max-w-md leading-relaxed text-ink/70">{text}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

const plans = [
  { name: "Free", blurb: "For trying it out", m: 0, y: 0, items: ["10 plans a month", "One calendar", "Browser capture"] },
  { name: "Pro", blurb: "For people with full calendars", m: 12, y: 9, hot: true, items: ["Unlimited plans", "All your calendars", "One-tap re-plan", "Protected focus blocks"] },
  { name: "Team", blurb: "For groups that share work", m: 24, y: 19, items: ["Everything in Pro", "Shared projects", "Workload view", "SSO and admin controls"] },
];

export function Pricing() {
  const [yearly, setYearly] = useState(true);
  return (
    <section id="pricing" className="mx-auto max-w-6xl px-5 py-20">
      <h2 className="font-display text-4xl font-bold tracking-tight lg:text-5xl">Pricing that stays out of the way.</h2>
      <div className="mt-6 flex items-center gap-3 text-sm">
        <span>Monthly</span>
        <button role="switch" aria-checked={yearly} aria-label="Bill yearly" onClick={() => setYearly(!yearly)} className="relative h-7 w-12 rounded-full bg-ink">
          <motion.span layout transition={{ type: "spring", stiffness: 500, damping: 32 }} className={`absolute top-1 h-5 w-5 rounded-full bg-white ${yearly ? "right-1" : "left-1"}`} />
        </button>
        <span>Yearly</span>
        <span className="rounded-full bg-sea/20 px-2 py-0.5 text-xs font-medium">Save up to 25%</span>
      </div>
      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {plans.map((p) => {
          const price = yearly ? p.y : p.m;
          return (
            <div key={p.name} className={`flex flex-col rounded-3xl p-7 ${p.hot ? "bg-ink text-white md:-translate-y-3" : "bg-white ring-1 ring-ink/10"}`}>
              <h3 className="font-display text-xl font-semibold">{p.name}</h3>
              <p className={`text-sm ${p.hot ? "text-white/70" : "text-ink/60"}`}>{p.blurb}</p>
              <p className="mt-6 flex items-baseline gap-1 overflow-hidden">
                <motion.span key={price} initial={{ y: 24, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="font-display text-5xl font-bold">${price}</motion.span>
                <span className={`text-sm ${p.hot ? "text-white/70" : "text-ink/60"}`}>{p.m ? "per seat, per month" : "forever"}</span>
              </p>
              <ul className="my-6 flex-1 space-y-2.5 text-sm">
                {p.items.map((i) => <li key={i} className="flex gap-2.5"><Check size={18} className={p.hot ? "text-sea" : "text-iris"} />{i}</li>)}
              </ul>
              <a href="#join" className={`rounded-full px-5 py-2.5 text-center text-sm font-medium transition ${p.hot ? "bg-white text-ink hover:bg-sea" : "bg-ink text-white hover:bg-iris"}`}>
                {p.m ? `Get ${p.name}` : "Start free"}
              </a>
            </div>
          );
        })}
      </div>
    </section>
  );
}

const faqs = [
  ["Does FlowAI read my calendar?", "Only if you connect it. It reads busy and free times to find gaps, and it never edits an event without asking."],
  ["How does it know which tasks are hard?", "It reads your wording and learns from how long tasks take you. You can correct any estimate and it remembers."],
  ["What happens to my lists?", "They're encrypted, and they're never used to train models. You can export or delete everything from settings."],
  ["When can I get in?", "We're inviting people in weekly waves. Join the waitlist and we'll email you when your invite is ready."],
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="mx-auto max-w-3xl px-5 py-20">
      <h2 className="font-display text-4xl font-bold tracking-tight">Questions, answered.</h2>
      <div className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
        {faqs.map(([q, a], i) => (
          <div key={q}>
            <button aria-expanded={open === i} onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-4 py-5 text-left text-lg font-medium">
              {q}
              <motion.span animate={{ rotate: open === i ? 180 : 0 }}><ChevronDown size={20} /></motion.span>
            </button>
            <AnimatePresence initial={false}>
              {open === i && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                  <p className="max-w-xl pb-5 leading-relaxed text-ink/70">{a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Join() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done">("idle");
  const [error, setError] = useState("");

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setState("loading");
    try {
      const res = await fetch("/api/waitlist", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong. Try again.");
      setState("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again.");
      setState("idle");
    }
  }

  return (
    <section id="join" className="mx-auto max-w-6xl px-5 pb-20">
      <div className="rounded-[2rem] bg-ink px-6 py-16 text-center text-white sm:px-12">
        <h2 className="mx-auto max-w-xl font-display text-4xl font-bold tracking-tight sm:text-5xl">Your next day could start like this.</h2>
        <p className="mx-auto mt-4 max-w-md text-white/70">Get an invite when your spot opens up.</p>
        {state === "done" ? (
          <motion.p initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto mt-8 flex max-w-md items-center justify-center gap-2 text-lg">
            <Check className="shrink-0 text-sea" /> You're on the list. We'll email {email} when your invite is ready.
          </motion.p>
        ) : (
          <form onSubmit={submit} noValidate className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row">
            <label htmlFor="email" className="sr-only">Email address</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@work.com" className="flex-1 rounded-full bg-white/10 px-5 py-3 text-white placeholder:text-white/50" />
            <button disabled={state === "loading"} className="rounded-full bg-iris px-6 py-3 font-medium transition hover:bg-sea disabled:opacity-60">
              {state === "loading" ? "Joining…" : "Join the waitlist"}
            </button>
          </form>
        )}
        {error && <p role="alert" className="mt-3 text-sm text-[#FFB4A8]">{error}</p>}
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-ink/10 px-5 py-8 text-center text-sm text-ink/60">
      © 2026 FlowAI. Plan less, do more.
    </footer>
  );
}
