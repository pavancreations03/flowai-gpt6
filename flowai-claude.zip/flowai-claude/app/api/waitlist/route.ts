import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { email } = (await req.json().catch(() => ({}))) as { email?: string };
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  // Persist here (Vercel KV, Resend audience, Airtable, etc.)
  return NextResponse.json({ ok: true });
}
