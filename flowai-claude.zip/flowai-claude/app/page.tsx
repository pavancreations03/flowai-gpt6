"use client";
import { MotionConfig } from "framer-motion";
import Demo from "@/components/Demo";
import { Nav, Features, Pricing, Faq, Join, Footer } from "@/components/Sections";

export default function Page() {
  return (
    <MotionConfig reducedMotion="user">
      <Nav />
      <main>
        <section className="mx-auto grid max-w-6xl gap-12 px-5 pb-24 pt-14 lg:grid-cols-[1fr_1.05fr] lg:items-center lg:pt-24">
          <div>
            <h1 className="font-display text-5xl font-extrabold leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">
              Dump your to-dos. Get a day that works.
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-ink/75">
              FlowAI turns a messy list into a realistic schedule: hard thinking in your best hours, quick tasks in the gaps, lunch left alone.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#join" className="rounded-full bg-iris px-6 py-3 font-medium text-white transition hover:bg-ink">Join the waitlist</a>
              <a href="#features" className="rounded-full border border-ink/20 px-6 py-3 font-medium transition hover:bg-white">See how it plans</a>
            </div>
            <p className="mt-4 text-sm text-ink/60">Free for individuals. No card needed.</p>
          </div>
          <Demo />
        </section>
        <Features />
        <Pricing />
        <Faq />
        <Join />
      </main>
      <Footer />
    </MotionConfig>
  );
}
